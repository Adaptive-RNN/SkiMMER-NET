clc
clear
close all

%% load data
%% The dataset is assumed to be stored in the following location: "D:\Datasets\"
%% I is input feature size
%% Maxdelay=500
load 'D:\Datasets\electricitypricing'; I = 8; name='ElecPrice';
%load 'D:\Datasets\Hepmass2m'; I = 28; name='Hepmass';
%data=load('D:\Datasets\3Dprinting1.txt');  I = 12; name='3Dprint';

%% run SkiMMER-NET

[parameter,performance] = skimmernet(data,I,name);
disp(performance)